import React from 'react';
import { Clock, Info, CheckCircle2, AlertCircle } from 'lucide-react';

interface Schedule {
  code: string;
  meaning: string;
  description: string;
}

const schedules: Schedule[] = [
  {
    code: '1-0-1',
    meaning: 'দিনে দুইবার',
    description: 'সকালে ১টি এবং রাতে ১টি। দুপুরে খাওয়ার প্রয়োজন নেই।'
  },
  {
    code: '0-1-0',
    meaning: 'দিনে একবার (দুপুরে)',
    description: 'শুধু দুপুরে ১টি ওষুধ খেতে হবে।'
  },
  {
    code: '1-1-1',
    meaning: 'দিনে তিনবার',
    description: 'সকালে ১টি, দুপুরে ১টি এবং রাতে ১টি।'
  },
  {
    code: 'HS (Hora Somni)',
    meaning: 'ঘুমানোর আগে',
    description: 'রাতে ঘুমানোর ঠিক আগে ওষুধটি খেতে হবে।'
  },
  {
    code: 'SOS (Si Opus Sit)',
    meaning: 'প্রয়োজন হলে',
    description: 'যখন সমস্যা হবে (যেমন খুব ব্যথা বা জ্বর), শুধুমাত্র তখনই খেতে হবে।'
  }
];

export const ScheduleGuide: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 flex items-start gap-3">
        <Info className="w-5 h-5 text-blue-600 mt-0.5" />
        <p className="text-sm text-blue-800 leading-relaxed">
          ডাক্তাররা অনেক সময় ওষুধের প্যাকেটে বা প্রেসক্রিপশনে কিছু সংকেত লিখে দেন। নিচে সাধারণ কিছু সংকেতের মানে দেওয়া হলো:
        </p>
      </div>

      <div className="grid gap-4">
        {schedules.map((item) => (
          <div key={item.code} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 hover:border-blue-200 transition-colors">
            <div className="flex items-center justify-between mb-2">
              <span className="text-lg font-bold text-blue-700">{item.code}</span>
              <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs font-medium rounded-md uppercase tracking-wider">
                {item.meaning}
              </span>
            </div>
            <p className="text-gray-600 text-sm leading-relaxed">{item.description}</p>
          </div>
        ))}
      </div>

      <div className="bg-amber-50 p-4 rounded-xl border border-amber-100 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5" />
        <div className="text-sm text-amber-900 space-y-1">
          <p className="font-semibold">মনে রাখবেন:</p>
          <ul className="list-disc list-inside space-y-1 opacity-90">
            <li>ওষুধ খাওয়ার আগে বা পরে খেতে হবে কি না তা নিশ্চিত হয়ে নিন।</li>
            <li>ডাক্তারের দেওয়া নির্দিষ্ট ডোজের বাইরে ওষুধ খাবেন না।</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
