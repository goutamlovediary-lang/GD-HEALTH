import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY || "" });

export async function analyzePrescription(imageData: string) {
  try {
    // Clean data URL prefix if present
    const base64Data = imageData.split(',')[1] || imageData;

    const prompt = `তুমি একজন অভিজ্ঞ বাংলা হেলথ ইনফরমেশন অ্যাসিস্ট্যান্ট। তোমার কাজ হলো এই প্রেসক্রিপশন ইমেজটি অত্যন্ত সতর্কতার সাথে বিশ্লেষণ করা।
সবার আগে, যদি প্রেসক্রিপশনটি সাধারণ মানুষের জন্য খুব জটিল হয় বা লেখা অস্পষ্ট হয়, তবে সেটা নম্রভাবে জানাবে।

বিশ্লেষণের ফরম্যাট (অবশ্যই বাংলায়):
১. ওষুধের নাম (Medicine Name)
২. কখন খেতে হবে (Timing)
৩. সাধারণ ব্যবহার (General Uses - যেমন: জ্বর, ব্যথা বা ইনফেকশন)
৪. খাবারের আগে নাকি পরে (Before/After Meal)

কিছু গুরুত্বপূর্ণ নিয়ম:
- কোন রোগনির্ণয় (Diagnosis) করবে না।
- কোন নির্দিষ্ট চিকিৎসা প্রেসক্রাইব করবে না।
- ভয় দেখাবে না।
- খুব সহজ এবং সাধারণ বাংলা শব্দ ব্যবহার করবে।
- যদি নিশ্চিত না হও, বলবে 'স্পষ্ট বোঝা যাচ্ছে না'।
- সবশেষে এই ডিসক্লেমারটি অবশ্যই দেবে: '**সঠিক চিকিৎসার জন্য অবশ্যই ডাক্তারের পরামর্শ অনুসরণ করুন**'।`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          parts: [
            { text: prompt },
            {
              inlineData: {
                data: base64Data,
                mimeType: "image/jpeg"
              }
            }
          ]
        }
      ]
    });

    return response.text || "দুঃখিত, কোনো ফলাফল পাওয়া যায়নি।";
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return "দুঃখিত, প্রেসক্রিপশনটি বিশ্লেষণ করতে সমস্যা হয়েছে। দয়া করে আবার চেষ্টা করুন।";
  }
}

export async function analyzeBloodReport(imageData: string) {
  try {
    const base64Data = imageData.split(',')[1] || imageData;

    const prompt = `তুমি একজন বাংলা হেলথ ইনফরমেশন অ্যাসিস্ট্যান্ট। এই ব্লাড রিপোর্টটি সাধারণ মানুষের জন্য সহজ বাংলায় ব্যাখ্যা করো।

বলবে:
- কোন ভ্যালু বেশি (High)
- কোন ভ্যালু কম (Low)
- সাধারণ অর্থ কী (সহজভাবে)

গুরুত্বপূর্ণ:
- কোন রোগনির্ণয় (Diagnose) করবে না।
- ভয় দেখাবে না।
- সহজ বাংলা ব্যবহার করবে।
- সবশেষে এই ডিসক্লেমারটি অবশ্যই দেবে: '**সঠিক চিকিৎসার জন্য অবশ্যই ডাক্তারের পরামর্শ অনুসরণ করুন**'।`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          parts: [
            { text: prompt },
            {
              inlineData: {
                data: base64Data,
                mimeType: "image/jpeg"
              }
            }
          ]
        }
      ]
    });

    return response.text || "দুঃখিত, কোনো ফলাফল পাওয়া যায়নি।";
  } catch (error) {
    console.error("Gemini Blood Report Error:", error);
    return "দুঃখিত, রিপোর্টটি বিশ্লেষণ করতে সমস্যা হয়েছে।";
  }
}
